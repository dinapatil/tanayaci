<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	 
	 function __construct() {
        parent::__construct();
        $this->load->model('usermodel');
    }
	 
	public function index()
	{
		$search_string = "";
     
        $search_string =  $this->input->post('usersearch', TRUE);
        $result = $this->usermodel->getDataList($search_string);
		$data['search_string'] = $search_string;

        $data['result'] = $result;
        
        $this->load->view('users-lists',$data);
	}
	
	
	public function add() {
	
		  $this->load->view('add-user');
	}
	
	public function save() {
		
		$name = $this->input->post("name", true);
		$email = $this->input->post("email", true);
		$contactno = $this->input->post("contactno", true);
		$city = $this->input->post("city", true);
		$status = $this->input->post("status", true);
		
		$dataarray = array (
			"name" => $name,
			"email" => $email,
			"contact_number" => $contactno,
			"city" => $city,
			"status" => $status,
			"created_date" => date("Y-m-d")
		);
		$insertId = $this->usermodel->saveData($dataarray);
		
		if($insertId) {
			redirect(base_url() . 'index.php/user');
			
		} else {
			$this->session->set_flashdata('message_name', 'Error:: please try again!');
			$this->load->view('add-user');
		}
	}
	
	public function edit($id) {
	
		
		 $data["resultarray"] = $this->usermodel->singleuserdata($id);
		 $data["tabId"] = $id;
		 $this->load->view('edit-user',$data);
			 
	}
	
	public function update($id) {
		
		$name = $this->input->post("name", true);
		$email = $this->input->post("email", true);
		$contactno = $this->input->post("contactno", true);
		$city = $this->input->post("city", true);
		$status = $this->input->post("status", true);
		
		$dataarray = array (
			"name" => $name,
			"email" => $email,
			"contact_number" => $contactno,
			"city" => $city,
			"status" => $status
		);
		$insertId = $this->usermodel->updateData($id,$dataarray);
		redirect(base_url() . 'index.php/user');
	}
	
	public function delete($id) {
	
		 $result = $this->usermodel->delete($id);     
        if($result) {
			$this->session->set_flashdata('message_name', 'Records deleted successfully!');
		} else {
			$this->session->set_flashdata('message_name', 'Error:: please try again!');
		}
		redirect(base_url() . 'index.php/user');
		
	}
	
	
}
