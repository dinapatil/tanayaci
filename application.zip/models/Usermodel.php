<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Usermodel extends CI_Model {

    function __construct()
    {
        parent::__construct();
        
        
    }
    
    
    public function getDataList($search_string) {
        try {
			
            $this->db->select('*');
            $this->db->from('user');
            if (!empty($search_string)) {
                $this->db->where(" ( name like '%$search_string%' OR email like '%$search_string%'  OR contact_number like '%$search_string%'  OR city like '%$search_string%' )");
            }
            
			$this->db->order_by('id','DESC');
            $query = $this->db->get();
        //    echo $this->db->last_query(); exit;
            if (($query)) {
                return $query->result();
            } else {
                throw new Exception("Failed to connct database");
            }
        } catch (Exception $ex) {
            log_message('error', $ex->getMessage());
            return $ex->getMessage();
        }
    }
    
    public function saveData($dataArray) {
		try {
            $this->db->insert('user', $dataArray);
            return $this->db->insert_id();
            
        } catch (Exception $ex) {
            log_message('error', $ex->getMessage());
            return $ex->getMessage();
        }
        
    }
    
     
    public function delete( $id) {
		
		try {
            $this->db->where('id', $id);
           $query = $this->db->delete('user');
            return $query;
        } catch (Exception $ex) {
            log_message('error', $ex->getMessage());
            return $ex->getMessage();
        }
        
    }
    
    function singleuserdata($id) {
		
		try {
            
            $this->db->select('*');
			$this->db->where('id', $id);
            $query = $this->db->get('user');
            return $query->row_array();
            
        } catch (Exception $ex) {
            log_message('error', $ex->getMessage());
            return $ex->getMessage();
        }
	}
	
	function updateData($id, $dataArray) {
		try {
            $this->db->where('id', $id);
            $this->db->update('user', $dataArray);
            return true;
        } catch (Exception $ex) {
            log_message('error', $ex->getMessage());
            return $ex->getMessage();
        }
	}
    
}
