<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

<style>
.error {
	color: red;
	font-weight: normal;
}
</style>
</head>
<body>

<div class="container">
  <h2>Add User Details</h2>
	<?php if($this->session->flashdata('message_name')) {?>
		<div class="main-box-body clearfix">
		<div class="alert alert-info text-center text-success">
			<?php echo $this->session->flashdata('message_name');?>
		</div><br />
	<?php } ?>
  <form enctype="multipart/form-data" id="addform" name="addform" method="post" action="<?php echo base_url(); ?>index.php/user/save" role="form" class="form-horizontal">
	  
	<div class="form-group">
    <label for="name">Name</label>
    <input type="text" class="form-control" id="name" name="name" placeholder="Enter Name">
  </div>
  
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email">
  </div>
  
  	  
<div class="form-group">
    <label for="contactno">Contact Number</label>
    <input type="text" class="form-control" id="contactno" name="contactno" placeholder="Enter Contact Number">
  </div>
  
  
<div class="form-group">
    <label for="city">City Name</label>
    <input type="text" class="form-control" id="city" name="city" placeholder="Enter City Name">
  </div>
  
  <div class="form-check">
    <input type="radio" class="form-check-input" value="active" name="status" checked>
    <label class="form-check-label" for="exampleCheck1" >Active</label>
	<input type="radio" class="form-check-input" value="inactive" name="status">
    <label class="form-check-label">Inactive</label>
    
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>

</div>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
</body>
</html>

<script>

$('#addform').validate({
  rules: {
    name: 'required',
   
    email: {
      required: true,
      email: true,
    },
    contactno: 'required',
    city: 'required'
  
  },
  submitHandler: function(form) {
    form.submit();
  }
});

</script>
