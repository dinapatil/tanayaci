<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

	
</head>
<body>

<div class="container">
  <h2>Users List</h2>
  
  	<?php if($this->session->flashdata('message_name')) {?>
		<div class="main-box-body clearfix">
		<div class="alert alert-info text-center text-success">
			<?php echo $this->session->flashdata('message_name');?>
		</div><br />
	<?php } ?>
  
  	<header class="main-box-header clearfix">
			<div class="filter-block pull-right">
				<div class="form-inline pull-left">
				  <form method="POST" action="<?php echo base_url(); ?>index.php/user" id="frmSearch" name="frmSearch">
						<input type="text"  placeholder="Search..." class="form-control  m-b-5" id="usersearch" name="usersearch" value="<?php echo !empty($search_string) ? $search_string : ''; ?>">
						<input type="hidden" name="resetsearch" value="reset"/>
						<a onclick="js_search_list();" href="JavaScript:void(0);" class="btn btn-success waves-effect w-md waves-light  m-b-5">SEARCH</a>
						<a  href="<?php echo base_url(); ?>index.php/user/add" class="btn btn-primary waves-effect w-md waves-light m-b-5">Add New</a>
					</form>                                
				</div>        
			</div>
			</header> <br><br>
					   
  <table class="table table-bordered">
    <thead>
      <tr>
		<th>Sr.no.</th>
        <th>Name</th>
        <th>Email</th>
        <th>Contact Number</th>
        <th>City</th>
        <th>Status</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
		
		<?php
		$srno = 1;
		foreach($result as $value) {
			
			$userid = $value->id;
			
		 ?>
		
      <tr>
		<td><?php echo $srno; ?></td>
        <td><?php echo $value->name; ?></td>
        <td><?php echo $value->email; ?></td>
        <td><?php echo $value->contact_number; ?></td>
        <td><?php echo $value->city; ?></td>
        <td><?php echo $value->status; ?></td>
        <td>
			<a href="<?php echo base_url(); ?>index.php/user/edit/<?php echo $userid; ?>">Edit</a> | 
			<a href="<?php echo base_url(); ?>index.php/user/delete/<?php echo $userid; ?>">Delete</a>
		</td>
      </tr>
      
      <?php 
		$srno++;
		
		}//foreach
      
      ?>
      
    </tbody>
  </table>
</div>

</body>
</html>


<script>
	
    function js_search_list() {
        document.getElementById("frmSearch").submit();
    }
   
</script>

