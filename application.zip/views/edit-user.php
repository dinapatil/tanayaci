<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

<style>
.error {
	color: red;
	font-weight: normal;
}
</style>
</head>
<body>

<div class="container">
  <h2>Update User Details</h2>

  <form enctype="multipart/form-data" id="addform" name="addform" method="post" action="<?php echo base_url(); ?>index.php/user/update/<?php echo $tabId; ?>" role="form" class="form-horizontal">
	  
	<div class="form-group">
    <label for="name">Name</label>
    <input type="text" class="form-control" id="name" name="name" placeholder="Enter Name" value="<?php echo $resultarray["name"]; ?>">
  </div>
  
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email" value="<?php echo $resultarray["email"]; ?>">
  </div>
  
  	  
<div class="form-group">
    <label for="contactno">Contact Number</label>
    <input type="text" class="form-control" id="contactno" name="contactno" placeholder="Enter Contact Number" value="<?php echo $resultarray["contact_number"]; ?>">
  </div>
  
  
<div class="form-group">
    <label for="city">City Name</label>
    <input type="text" class="form-control" id="city" name="city" placeholder="Enter City Name"  value="<?php echo $resultarray["city"]; ?>">
  </div>
  
  <div class="form-check">
    <input type="radio" class="form-check-input" value="active" name="status"  <?php if( $resultarray["status"] == 'active') echo 'checked'; ?> >
    <label class="form-check-label" for="exampleCheck1" >Active</label>
	<input type="radio" class="form-check-input" value="inactive" name="status" <?php if( $resultarray["status"] == 'inactive') echo 'checked'; ?> >
    <label class="form-check-label">Inactive</label>
    
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>

</div>
<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js"></script>
</body>
</html>

<script>

$('#addform').validate({
  rules: {
    name: 'required',
   
    email: {
      required: true,
      email: true,
    },
    contactno: 'required',
    city: 'required'
  
  },
  submitHandler: function(form) {
    form.submit();
  }
});

</script>
